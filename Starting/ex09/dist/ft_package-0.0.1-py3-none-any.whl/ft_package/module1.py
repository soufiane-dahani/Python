# ft_package/module1.py

def hello():
    print("Hello from module1.py!")