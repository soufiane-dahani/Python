# ft_package/module2.py

def hello2():
    print("Hello from module2.py!")